package com.infinite.customerapp.web;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.infinite.customerapp.dao.CustomerDAO;
import com.infinite.customerapp.dao.CustomerEntity;
import com.infinite.customerapp.model.CustomerDataBean;


@Path("customer")
public class CustomerController {

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/{customerId}")
    public CustomerDataBean getCustomer(@PathParam("customerId") int customerId) {

        CustomerDAO dao = new CustomerDAO();
        CustomerEntity dbEntity = dao.getCustomer(customerId);

        CustomerDataBean customerBean = new CustomerDataBean();
        if (dbEntity != null) {
            customerBean.setCompanyName(dbEntity.getCompanyName());
            customerBean.setCustomerDBId(dbEntity.getCustomerDbId());
            customerBean.setCustomerId(dbEntity.getCustomerId());
            customerBean.setCustomerName(dbEntity.getCustomerName());
            customerBean.setCompanyOrgId(dbEntity.getCompanyOrgId());
        }

        return customerBean;
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    public CustomerDataBean addCustomer(CustomerDataBean dataBean) {

        CustomerDAO dao = new CustomerDAO();

        CustomerEntity dbEntity = new CustomerEntity();
        dbEntity.setCompanyName(dataBean.getCompanyName());
        dbEntity.setCustomerDbId(dataBean.getCustomerDBId());
        dbEntity.setCustomerName(dataBean.getCustomerName());
        dbEntity.setCompanyOrgId(dataBean.getCompanyOrgId());

        CustomerEntity savedEntity = dao.addCustomer(dbEntity);

        CustomerDataBean outputBean = new CustomerDataBean();
        outputBean.setCustomerId(savedEntity.getCustomerId());

        return outputBean;
    }

    @GET
    @Path("all")
    @Produces(MediaType.APPLICATION_JSON)
    public List<CustomerDataBean> getAllCustomers() {

        CustomerDAO dao = new CustomerDAO();
        List<CustomerEntity> dbEntities = dao.getAllCustomers();

        List<CustomerDataBean> allCustomerData = new ArrayList<>();
        for (CustomerEntity dbEntity : dbEntities) {
            CustomerDataBean customerBean = new CustomerDataBean();
            customerBean.setCompanyName(dbEntity.getCompanyName());
            customerBean.setCustomerDBId(dbEntity.getCustomerDbId());
            customerBean.setCustomerId(dbEntity.getCustomerId());
            customerBean.setCustomerName(dbEntity.getCustomerName());
            customerBean.setCompanyOrgId(dbEntity.getCompanyOrgId());
            allCustomerData.add(customerBean);
        }

        return allCustomerData;
    }
}
