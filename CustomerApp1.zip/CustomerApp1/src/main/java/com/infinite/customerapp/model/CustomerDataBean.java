package com.infinite.customerapp.model;

import java.io.Serializable;


public class CustomerDataBean implements Serializable {

    private static final long serialVersionUID = 2309942114957121294L;

    private Integer customerId;
    private String customerName;
    private Integer companyOrgId;
    private String companyName;
    private Integer customerDBId;

    public Integer getCustomerId() {

        return customerId;
    }

    public void setCustomerId(Integer customerId) {

        this.customerId = customerId;
    }

    public String getCustomerName() {

        return customerName;
    }

    public void setCustomerName(String customerName) {

        this.customerName = customerName;
    }

    public String getCompanyName() {

        return companyName;
    }

    public void setCompanyName(String companyName) {

        this.companyName = companyName;
    }

    public Integer getCustomerDBId() {

        return customerDBId;
    }

    public void setCustomerDBId(Integer customerDBId) {

        this.customerDBId = customerDBId;
    }

    public Integer getCompanyOrgId() {

        return companyOrgId;
    }

    public void setCompanyOrgId(Integer companyOrgId) {

        this.companyOrgId = companyOrgId;
    }

}
