package com.infinite.customerapp.dao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "CUSTOMER")
public class CustomerEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CUSTOMER_ID", nullable = false)
    private Integer customerId;

    @Column(name = "CUSTOMER_NAME", nullable = false)
    private String customerName;

    @Column(name = "COMPANY_ORGID", nullable = false)
    private Integer companyOrgId;

    @Column(name = "COMPANY_NAME", nullable = false)
    private String companyName;

    @Column(name = "CUSTOMER_DBID", nullable = false)
    private Integer customerDbId;

    public Integer getCustomerId() {

        return customerId;
    }

    public void setCustomerId(Integer customerId) {

        this.customerId = customerId;
    }

    public String getCustomerName() {

        return customerName;
    }

    public void setCustomerName(String customerName) {

        this.customerName = customerName;
    }

    public String getCompanyName() {

        return companyName;
    }

    public void setCompanyName(String companyName) {

        this.companyName = companyName;
    }

    public Integer getCustomerDbId() {

        return customerDbId;
    }

    public void setCustomerDbId(Integer customerDbId) {

        this.customerDbId = customerDbId;
    }

    public Integer getCompanyOrgId() {

        return companyOrgId;
    }

    public void setCompanyOrgId(Integer companyOrgId) {

        this.companyOrgId = companyOrgId;
    }

}
