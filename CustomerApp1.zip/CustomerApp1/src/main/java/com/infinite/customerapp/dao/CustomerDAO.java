package com.infinite.customerapp.dao;

import javax.persistence.NoResultException;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;


public class CustomerDAO {

    public CustomerEntity addCustomer(CustomerEntity entity) {

        Session session = SessionUtil.getSession();
        Transaction tx = session.beginTransaction();
        session.save(entity);
        tx.commit();
        session.close();

        return entity;
    }

    public CustomerEntity getCustomer(final int customerId) {

        Session session = SessionUtil.getSession();
        String hql = "from CustomerEntity where customerId = :customerId";

        Query query = session.createQuery(hql);
        query.setInteger("customerId", customerId);

        CustomerEntity entity = new CustomerEntity();

        try {
            entity = (CustomerEntity) query.getSingleResult();
        } catch (NoResultException ex) {
            //No result found
        }

        session.close();
        return entity;
    }

}
